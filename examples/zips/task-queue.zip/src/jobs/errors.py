class QueueFull(Exception):
    pass
